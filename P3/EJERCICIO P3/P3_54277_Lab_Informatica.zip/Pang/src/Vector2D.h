#pragma once

class Vector2D
{
private:
	float x;
	float y;
public:
	void SetCoordenadas(float _x, float _y);
	float GetX();
	float GetY();
};


