#pragma once

class Toroide
{
private:
	float radioInt = 2;
	float radioExt = 4;
	float sides = 50;
	float rings = 100;
public:
	void mueve();
	void Drawtoroide();
};

